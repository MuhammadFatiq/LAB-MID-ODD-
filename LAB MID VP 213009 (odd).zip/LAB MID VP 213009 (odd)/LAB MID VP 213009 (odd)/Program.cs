﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace RestaurantMenuApp
{
    public partial class Form1 : Form
    {
        private List<MenuItem> menuItems = new List<MenuItem>();
        private List<MenuItem> orderItems = new List<MenuItem>();

        public Form1()
        {
            InitializeComponent();

           
            menuItems.Add(new MenuItem("Burger", , 8.99));
            menuItems.Add(new MenuItem("Pizza", , 10.99));
            menuItems.Add(new MenuItem("Pasta", 9.99));

            
            foreach (MenuItem item in menuItems)
            {
                listBoxMenu.Items.Add(item.Name);
            }
        }

        private void listBoxMenu_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = listBoxMenu.SelectedIndex;
            if (selectedIndex >= 0)
            {
                MenuItem selectedItem = menuItems[selectedIndex];
                listBoxOrder.Items.Add(selectedItem.Name);
                orderItems.Add(selectedItem);
            }
        }

        private void buttonPlaceOrder_Click(object sender, EventArgs e)
        {
            double totalCost = 0;
            foreach (MenuItem item in orderItems)
            {
                totalCost += item.Price;
            }

            MessageBox.Show("Order Total: $" + totalCost.ToString("0.00"));
        }
    }
}

public class MenuItem
{
    public string Name { get; set; }
    public string Description { get; set; }
    public double Price { get; set; }

    public MenuItem(string name, string description, double price)
    {
        Name = name;
        Description = description;
        Price = price;
    }
}
